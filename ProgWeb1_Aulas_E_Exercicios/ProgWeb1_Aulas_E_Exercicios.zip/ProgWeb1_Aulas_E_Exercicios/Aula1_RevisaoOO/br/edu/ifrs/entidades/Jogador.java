package br.edu.ifrs.entidades;

public class Jogador {

}
