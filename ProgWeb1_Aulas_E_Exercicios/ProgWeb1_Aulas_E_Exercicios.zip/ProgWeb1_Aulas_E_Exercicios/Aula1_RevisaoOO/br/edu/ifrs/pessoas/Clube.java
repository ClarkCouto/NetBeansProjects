package br.edu.ifrs.pessoas;

public class Clube {

}
