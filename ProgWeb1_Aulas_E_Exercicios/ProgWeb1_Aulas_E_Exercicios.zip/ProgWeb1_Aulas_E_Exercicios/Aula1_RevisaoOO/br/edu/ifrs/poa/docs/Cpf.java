/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.poa.docs;

/**
 *
 * @author 0729159
 */
public class Cpf {
    private long numero;
    private int digito;

    public Cpf(long numero, int digito) {
        this.numero = numero;
        this.digito = digito;
    }

    public long getNumero() {
        return numero;
    }

    public int getDigito() {
        return digito;
    }

    public void setNumero(long numero) {
        this.numero = numero;
    }

    public void setDigito(int digito) {
        this.digito = digito;
    }

    @Override
    public String toString() {
        return "Cpf{Número = " + numero + " - " + digito + '}';
    }  
}
