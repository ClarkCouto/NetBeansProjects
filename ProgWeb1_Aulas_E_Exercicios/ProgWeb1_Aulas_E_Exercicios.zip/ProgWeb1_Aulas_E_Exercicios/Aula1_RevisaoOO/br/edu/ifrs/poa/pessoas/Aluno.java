/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrs.poa.pessoas;

import br.edu.ifrs.poa.docs.Cpf;

/**
 *
 * @author 0729159
 */
public class Aluno extends Pessoa{
    private long matricula;
    private String curso;
    private int situacao;
    private Cpf cpf;
    
    public Aluno() {
    }

    public Aluno(String nome, String telefone, String endereco, long matricula, String curso, int situacao) {
        super(nome, telefone, endereco);
        this.matricula = matricula;
        this.curso = curso;
        this.situacao = situacao;
    }

    public Aluno(String nome, String telefone, String endereco, long matricula, String curso, int situacao, Cpf cpf) {
        super(nome, telefone, endereco);
        this.matricula = matricula;
        this.curso = curso;
        this.situacao = situacao;
        this.cpf = cpf;
    }
    
    public long getMatricula() {
        return matricula;
    }

    public Cpf getCpf() {
        return cpf;
    }

    public void setCpf(Cpf cpf) {
        this.cpf = cpf;
    }
    
    public String getCurso() {
        return curso;
    }

    public int getSituacao() {
        return situacao;
    }

    public void setMatricula(long matricula) {
        this.matricula = matricula;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public void setSituacao(int situacao) {
        this.situacao = situacao;
    }

    @Override
    public String toString() {
        return super.toString() + 
            "\nAluno{" + "Matricula = " + matricula + ", Curso = " + curso + ", Situacao = " + situacao + "}\n" +
            (cpf != null ? cpf.toString() : "CPF Inválido");
    }
    
    @Override
    public void imprime(){
        System.out.println(toString());
    }
    
}
