package exercicio01_2_3_4_Curso_Composicao;


import java.util.ArrayList;

import javax.swing.JOptionPane;

import exercicio05_6_7.Data;

public class TesteCurso {

	//Questão 2
//	public static void main(String[] args) {
//		Curso curso1 = new Curso();
//		curso1.imprime();
//		//System.out.println(curso1.toString());
//		Data data1 = new Data();
//		Curso curso2 = new Curso("Java I", 8.0, data1);
//		curso2.imprime();
//		//System.out.println(curso2.toString());
//		Data data2 = new Data(20, 8, 2014);
//		Curso curso3 = new Curso("Java II", 8.0, data2);
//		curso3.imprime();
//		//System.out.println(curso3.toString());

	//Resposta Questão 2
//	Curso: null Duração: 0.0 Data: null
//	Curso: Java I Duração: 8.0 Data: Data = 0/0/0
//	Curso: Java II Duração: 8.0 Data: Data = 20/8/2014
//	}
	

	//Questão 3
//	public static void main(String[] args) {
//		Curso curso1 = new Curso();
//		System.out.println(curso1.toString());
//		Data data1 = new Data();
//		curso1.setData(data1);
//		Curso curso2 = new Curso("Java I", 8.0, data1);
//		System.out.println(curso2.toString());
//		data1.setAno(2013);
//		System.out.println(curso2.getData());
		
		//Resposta Questão 3
//		Curso: null Duração: 0.0 Data: null
//		Curso: Java I Duração: 8.0 Data: Data = 0/0/0
//		Data = 0/0/2013
//	}
	
	//Questão 4
	public static void main(String[] args) {
		ArrayList<Curso> lista = new ArrayList<Curso>(); 
		int opcao = 0; 
		while(opcao != 5){
			System.out.println(menu());
			try{
				opcao = Integer.parseInt(JOptionPane.showInputDialog("Digite a opção: ")); 
				boolean encontrou = false;
				String encontrado = "";
				switch(opcao){
					case 1:
						String nome = JOptionPane.showInputDialog("Digite o nome: ");
						Double duracao = Double.parseDouble(JOptionPane.showInputDialog("Digite a duração: "));
						int dia = Integer.parseInt(JOptionPane.showInputDialog("Digite o dia: ")); 
						int mes = Integer.parseInt(JOptionPane.showInputDialog("Digite o mês: ")); 
						int ano = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano: ")); 
						Curso c = new Curso(nome, duracao, new Data(dia, mes, ano));
						lista.add(c);
						break;
					case 2:
						String buscarNome = JOptionPane.showInputDialog("Digite o nome a ser encontrado: ");
						for(Curso cur : lista){
							if(cur.getNome().equals(buscarNome))
								encontrou = true;
						}
						encontrado = encontrou == true ? "" : " não";
						JOptionPane.showMessageDialog(null,"O curso " + buscarNome + encontrado + " foi encontrado");
						break;
					case 3:
						dia = Integer.parseInt(JOptionPane.showInputDialog("Digite o dia: ")); 
						mes = Integer.parseInt(JOptionPane.showInputDialog("Digite o mês: ")); 
						ano = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano: ")); 
						Data d = new Data(dia, mes, ano);
						for(Curso cur : lista){
							if(cur.getData().equals(d)){
								encontrou = true;
								JOptionPane.showMessageDialog(null,"O curso " + cur.getNome() + " foi encontrado");
							}
						}
						if(!encontrou)
							JOptionPane.showMessageDialog(null,"Nenhum curso foi encontrado em " + d);						
						break;
					case 4:
						if(lista.isEmpty())
							JOptionPane.showMessageDialog(null,"Nenhum curso foi encontrado! Lista vazia!");
						else{
							for(Curso cur : lista)
								JOptionPane.showMessageDialog(null,"O curso " + cur.getNome() + " foi encontrado");
						}
						break;
					case 5:
						//JOptionPane.showMessageDialog(null,"Encerrando...");
						System.exit(0);
						break;
				}
			}
			catch(Exception e){
				JOptionPane.showMessageDialog(null,"Opção Inválida!");
			}
		}
	}
	
	public static String menu(){
		return "==================== MENU =====================\n"+
				"1 – Cadastrar Curso\n"+
				"2 – Pesquisar Curso usando o nome\n"+
				"3 – Pesquisar Curso usando a data em que ocorre\n"+
				"4 – Listar todos os cursos\n"+
				"5 - Sair\n";
	}
	
}
