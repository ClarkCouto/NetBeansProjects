package exercicio05_6_7;


import java.util.Date;

public class Data{
	private int dia;
	private int mes;
	private int ano;

	public Data() {}
		
	public Data(int dia, int mes, int ano) {
		this.dia = dia;
		this.mes = mes;
		this.ano = ano;
	}
	
	public int getDia() {
		return dia;
	}
	public void setDia(int dia) {
		this.dia = dia;
	}
	public int getMes() {
		return mes;
	}
	public void setMes(int mes) {
		this.mes = mes;
	}
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	@Override
	public String toString() {
		return dia + "/" + mes + "/" + ano;
	}
	
	public void imprime(){
		System.out.println(toString());
	}

	public int compareTo(Data d) {
		Date d1 = new Date(this.toString());
		Date d2 = new Date(d.toString());
		if(d1.before(d2))
			return -1;
		else if(d1.equals(d2))
			return 0;
		else
			return 1;		
	}
}
