package exercicio05_6_7;


import java.util.ArrayList;

import javax.swing.JOptionPane;


public class TesteProjeto {
	
//	6) UsandoasclassesdaQuestão5determineoqueseráimpressopelocódigoabaixo:
	public static void main(String[] args) {
		Projeto vetorProjs[] = new Projeto[6];
		vetorProjs[0] = new Projeto();
		Data data = new Data(12, 12, 2014);
		vetorProjs[0] = new Projeto("SIA", new Data(14, 05, 2014), data); 
		vetorProjs[1] = vetorProjs[0];
		vetorProjs[1].setDataFim(new Data(31, 01, 2015)); 

		System.out.println("Primeira passagem...");
		for (int i = 0; i < vetorProjs.length; i++) {
			if(vetorProjs[i] != null)
				System.out.println(vetorProjs[i].toString());
		}
		data = vetorProjs[0].getDataInicio();
		data.setDia(21);
		vetorProjs[1].setDataFim(data);
		
		System.out.println("\nSegunda passagem...");
		for (int i = 0; i < vetorProjs.length; i++) {
			if(vetorProjs[i] != null)
				System.out.println(vetorProjs[i].toString());
		}
		
//		7) Usando as classes da Questão 5 monte o menu abaixo usando vetores, seguindo as orientações abaixo:
//			1 – Cadastrar Projeto
//			2 – Pesquisar Projeto usando título 
//			3 – Pesquisar Projeto usando a data 
//			4 – Listar todos
//			5 – Sair
		
		int opcao = 0;
		ArrayList<Projeto> projetos = new ArrayList<Projeto>();
		while(opcao != 5){
			executar(menu(), projetos);
		}
	}
	
	public static int menu(){
		try{
			return Integer.parseInt(JOptionPane.showInputDialog(
					"============== Menu =============\n" + 
					"1 - Cadastrar Projeto\n" + 
					"2 - Pesquisar Projeto pelo Título\n" + 
					"3 - Pesquisar Projeto pela Data\n" + 
					"4 - Listar Todos os Projetos\n" + 
					"5 - Sair\n" +
					"6 - Pesquisar por Periodo\n\n" +
					"Digite a opção desejada:"));
		}
		catch(Exception e){
			return 777;
		}
	}
	
	public static void executar(int opcao, ArrayList<Projeto> l){
		ArrayList<Projeto> lista = l;
		switch(opcao){
			case 1:
				try{
					String titulo = JOptionPane.showInputDialog("Digite o título: ");
					
					String partes[] = JOptionPane.showInputDialog("Digite a Data de Início: ").split("/");
					int dia = Integer.parseInt(partes[0]); 
					int mes = Integer.parseInt(partes[1]); 
					int ano = Integer.parseInt(partes[2]); 
					Data dataInicio = new Data(dia, mes, ano);
					
					String partesFim[] = JOptionPane.showInputDialog("Digite a Data de Fim: ").split("/");
					dia = Integer.parseInt(partesFim[0]); 
					mes = Integer.parseInt(partesFim[1]); 
					ano = Integer.parseInt(partesFim[2]); 
					Data dataFim = new Data(dia, mes, ano);
					
					lista.add(new Projeto(titulo, dataInicio, dataFim));
					JOptionPane.showMessageDialog(null, "Projeto Inserido!");
				}
				catch(Exception e){
					JOptionPane.showMessageDialog(null, "Não foi possível inserir o projeto!");
				}
				break;
			case 2:
				try{
					String titulo = JOptionPane.showInputDialog("Digite o título a ser encontrado: ");
					boolean encontrou = false;
					for(Projeto p : lista){
						if(p.getTitulo().equals(titulo))
							encontrou = true;
					}
					String encontrado = encontrou ? "" : " não";
					JOptionPane.showMessageDialog(null,  "O Projeto " + titulo + encontrado +" foi encontrado da lista");
				}
				catch(Exception e){
					JOptionPane.showMessageDialog(null, "Ocorreu um erro!");
				}
				break;
			case 3:
				try{
					Data data = null;
					String partes[] = JOptionPane.showInputDialog("Digite a Data: ").split("/");
					int dia = Integer.parseInt(partes[0]); 
					int mes = Integer.parseInt(partes[1]); 
					int ano = Integer.parseInt(partes[2]); 
					data = new Data(dia, mes, ano);
					boolean encontrou = false;
					for(Projeto p : lista){
						if(p.dataInicio.compareTo(data) == 0){
							JOptionPane.showMessageDialog(null, p.toString());
							encontrou = true;
						}
					}
					if(!encontrou)
						JOptionPane.showMessageDialog(null,  "Nenhum Projeto foi encontrado na data " + data.toString());
				}
				catch(Exception e){
					JOptionPane.showMessageDialog(null,  "Ocorreu um erro!");
				}
				break;
			case 4:
				if(lista.isEmpty()){
					JOptionPane.showMessageDialog(null,  "A lista está vazia!");
					break;
				}
				for(Projeto p : lista)
					JOptionPane.showMessageDialog(null, p.toString());
				break;
			case 5:
				//JOptionPane.showMessageDialog(null,"Encerrando...");
				System.exit(0);
				break;
			case 6:
				try{
					Data dataInicio = null;
					Data dataFim = null;
					try{
						String partes[] = JOptionPane.showInputDialog("Digite a Data de Início: ").split("/");
						int dia = Integer.parseInt(partes[0]); 
						int mes = Integer.parseInt(partes[1]); 
						int ano = Integer.parseInt(partes[2]); 
						dataInicio = new Data(dia, mes, ano);
					}
					catch(Exception e){}

					try{
						String partes[] = JOptionPane.showInputDialog("Digite a Data de Fim: ").split("/");
						int dia = Integer.parseInt(partes[0]); 
						int mes = Integer.parseInt(partes[1]); 
						int ano = Integer.parseInt(partes[2]); 
						dataFim = new Data(dia, mes, ano);
					}
					catch(Exception e){}
					boolean encontrou = false;
					for(Projeto p : lista){
						if(dataInicio != null && dataFim != null){
							if(p.dataInicio.compareTo(dataInicio) >= 0 && p.dataFim.compareTo(dataFim) <= 0){
								JOptionPane.showMessageDialog(null, p.toString());
								encontrou = true;
							}
						}
						else if(dataInicio != null){
							if(p.dataInicio.compareTo(dataInicio) >= 0){
								JOptionPane.showMessageDialog(null, p.toString());
								encontrou = true;
							}
						}
						else if(dataFim != null){
							if(p.dataFim.compareTo(dataFim) <= 0){
								JOptionPane.showMessageDialog(null, p.toString());
								encontrou = true;
							}
						}
					}
					if(!encontrou)
						JOptionPane.showMessageDialog(null,  "Nenhum Projeto foi encontrado no período entre " + (dataInicio != null ? dataInicio.toString() : " (não informado) ") + " e " + (dataFim != null ? dataFim.toString() : " (não informado) "));
				}
				catch(Exception e){
					JOptionPane.showMessageDialog(null,  "Ocorreu um erro!");
				}
				break;
			default:
				JOptionPane.showMessageDialog(null, "Opção inválida!");
				break;
		}
	}

}
