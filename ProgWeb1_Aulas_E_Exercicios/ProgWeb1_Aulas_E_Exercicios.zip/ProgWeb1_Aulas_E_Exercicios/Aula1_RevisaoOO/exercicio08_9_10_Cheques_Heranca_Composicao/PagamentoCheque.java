package exercicio08_9_10_Cheques_Heranca_Composicao;



public class PagamentoCheque extends Pagamento{
	String data;
	Cheque lista[];

	public PagamentoCheque(){}
	
	public PagamentoCheque(double total, String data, Cheque c[]) {
		super(total);
		this.data = data;
		this.lista = c;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public Cheque[] getLista() {
		return lista;
	}

	public void setLista(Cheque[] lista) {
		this.lista = lista;
	}

	@Override
	public String toString() {
		return "PagamentoCheque data: " + data + " valor: " + total;
	}
}
