package exercicio13_Mapa_Clientes;


public class Endereco {
	String logradouro;
	String complemento;
	
	public Endereco(){};
	public Endereco(String logradouro, String complemento) {
		super();
		this.logradouro = logradouro;
		this.complemento = complemento;
	}
	public String getLogradouro() {
		return logradouro;
	}
	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}
	public String getComplemento() {
		return complemento;
	}
	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}
	@Override
	public String toString() {
		return "Endereço: " + logradouro + " Complemento: " + complemento;
	}
	
}
