package exercicio14_Classe_Generica_Par;


public class TestePar {

	public static void main(String[] args) {
		Par<Integer, String> mes = new Par<>(); 
		mes.setPrimeiro(1); mes.setSegundo("Janeiro"); 
		System.out.println(mes.toString()); 
		mes.setPrimeiro(2); 
		mes.setSegundo("Fevereiro"); 
		System.out.println(mes.toString());
	}

}
