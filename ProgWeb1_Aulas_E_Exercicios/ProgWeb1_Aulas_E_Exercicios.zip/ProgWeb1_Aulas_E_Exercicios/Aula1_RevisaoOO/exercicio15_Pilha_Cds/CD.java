package exercicio15_Pilha_Cds;


public class CD {
	String titulo;
	int ano;
	String banda;
	
	public CD(){};
	public CD(String titulo, int ano, String banda) {
		super();
		this.titulo = titulo;
		this.ano = ano;
		this.banda = banda;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	public String getBanda() {
		return banda;
	}
	public void setBanda(String banda) {
		this.banda = banda;
	}
	@Override
	public String toString() {
		return "Título: " + titulo + " Ano: " + ano + " Banda:" + banda;
	}
	
	
}
