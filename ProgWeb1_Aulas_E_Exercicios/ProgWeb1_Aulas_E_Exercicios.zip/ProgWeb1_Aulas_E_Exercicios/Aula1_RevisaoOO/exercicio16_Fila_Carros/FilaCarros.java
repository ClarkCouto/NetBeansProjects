package exercicio16_Fila_Carros;


import java.util.LinkedList;

public class FilaCarros {
//	16) Crie uma classe com o nome FilaCarros que deve armazenar os carros que devem ser emplacados em um CRVA. 
//	Você deve inserir 5 carros na fila, imprimir todos os objetos inseridos. Depois, excluir 2 e imprimir 
//	todos os carros que restaram na fila novamente.
//	(obs.: para resolver esse exercício use a classe LinkedList; a classe Carro acima e implementar toda a 
//	solução usando os conceitos de fila).
	
	public static void main(String[] args) {
		LinkedList<Carro> filaCarros = new LinkedList<Carro>();
		filaCarros.add(new Carro("AAA 1111", 2000, "Gol"));
		filaCarros.add(new Carro("BBB 2222", 2002, "Ka"));
		filaCarros.add(new Carro("CCC 3333", 2007, "Pajero"));
		filaCarros.add(new Carro("DDD 4444", 2010, "BMW"));
		filaCarros.add(new Carro("EEE 5555", 2017, "Range Rover"));
		
		System.out.println("Fila Inicial (" + filaCarros.size() + " itens)");
		for(Carro c : filaCarros)
			System.out.println(c.toString());
		
		System.out.println("\nRemovendo 2 carros");
		filaCarros.removeFirst();
		filaCarros.removeFirst();

		System.out.println("\nFila Final (" + filaCarros.size() + " itens)");
		for(Carro c : filaCarros)
			System.out.println(c.toString());
	}

}
