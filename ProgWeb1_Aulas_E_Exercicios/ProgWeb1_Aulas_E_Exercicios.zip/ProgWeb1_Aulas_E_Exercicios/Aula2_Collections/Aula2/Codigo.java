package Aula2;

public class Codigo <S, C> {
	/*
	Crie uma classe gen�rica�Codigo�para representar os c�digos dos Produtos
	c�digos s�o compostos por duas partes que indicam o setor onde o produto � 
	fabricado (setor pode ser String ou n�mero); e 
	n�meros que s�o um c�digo sequencial dentro do setor
	Exemplos v�lidos: IMM120; IMM121 � 111120; 111121)
	*/
	private S setor;
	private C codigo;
	
	public Codigo(){}
	
	public Codigo(S s, C c){
		this.setor = s;
		this.codigo = c;
	}
	
	public S getSetor(){
		return this.setor;
	}
	
	public C getCodigo(){
		return this.codigo;
	}
	
	public void setSetor(S s){
		this.setor = s;
	}
	
	public void setCodigo(C c){
		this.codigo = c;
	}

	@Override
	public String toString() {
		return "Codigo [setor=" + setor + ", codigo=" + codigo + "]";
	}
}
