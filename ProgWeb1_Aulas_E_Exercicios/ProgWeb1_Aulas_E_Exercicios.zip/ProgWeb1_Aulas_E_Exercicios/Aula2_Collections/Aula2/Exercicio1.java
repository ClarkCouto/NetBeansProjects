package Aula2;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import javax.swing.JOptionPane;

import java.text.DecimalFormat; 

public class Exercicio1 {
	public static void main(String[] args) {
    //	Crie uma cole��o com n�meros do tipo Double
    //	Ordene os n�meros da cole��o criada no item 1 usando a classe Collections
	//	Modifique a ordem dos elementos da cole��o criada no item 1 usando um m�todo da classe Collections
	//	Leia um n�mero e verifique se ele est� na cole��o criada no item 1

		ArrayList<Double> lista = new ArrayList<Double>();
		Random geradorNumeros = new Random();
		DecimalFormat df = new DecimalFormat("##.00"); 
		
		for(int i = 0; i < 10; i++){
	        double numero = geradorNumeros.nextDouble() * 100;
			lista.add(numero);
		}
		
		for(int i = 0; i< lista.size(); i++){
			System.out.println("N�mero " + (i+1) + " = " + df.format(lista.get(i)));
		}
	
		Collections.sort(lista);
		
		//Collections.swap(lista, i, j);
		
		for(Double d : lista){
			System.out.println(df.format(d));
		}
		double num = 0;
		while(num != 999){
			num = Double.parseDouble(JOptionPane.showInputDialog("Digite o n�mero: "));
			int resultado =  Collections.binarySearch(lista, num);
			String encontrou = resultado == -1 ? " n�o" : "";
			JOptionPane.showMessageDialog(null, "O n�mero " + num + encontrou + " foi encontrado na lista");
		}
	}
}
