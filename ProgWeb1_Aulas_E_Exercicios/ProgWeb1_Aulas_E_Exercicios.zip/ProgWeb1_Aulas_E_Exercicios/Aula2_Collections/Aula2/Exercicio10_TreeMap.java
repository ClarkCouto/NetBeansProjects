package Aula2;
import java.util.Set;
import java.util.TreeMap;

public class Exercicio10_TreeMap {
	public static void main(String[] args) {
		//Usando as classes Cpf e Aluno fa�a
		//Adicionar em um TreeMap alunos usando os construtores sem e com par�metros, 
		//onde a chave � o Cpf e o valor um objeto aluno
		//Ordenar o mapa usando o Cpf
		//Imprimir o mapa ordenado
		
		TreeMap<Cpf, Aluno> mapaAlunos = new TreeMap<>();

		Cpf cpf = new Cpf(123456789,10);
		Aluno aluno = new Aluno("Cristiano", "99999999", "Cristo Redentor", 111111L, cpf);
		mapaAlunos.put(cpf, aluno);
		
		cpf = new Cpf(987987987,10);
		aluno = new Aluno("Vanessa", "88888888", "Humaita", 222222L, cpf);
		mapaAlunos.put(cpf, aluno);
		
		cpf = new Cpf();
		aluno = new Aluno();
		mapaAlunos.put(cpf, aluno);

		cpf = new Cpf(123123123,01);
		aluno = new Aluno("Thayse", "77777777", "Canoas", 333333L, cpf);
		mapaAlunos.put(cpf, aluno);

		cpf = new Cpf(456456456,00);
		aluno = new Aluno("Matheus", "66666666", "Vila Ipiranga", 444444L, cpf);
		mapaAlunos.put(cpf, aluno);
		
		cpf = new Cpf();
		aluno = new Aluno();
		mapaAlunos.put(cpf, aluno);

		Set<Cpf> chaves = mapaAlunos.keySet();
		for(Cpf chave: chaves)
			System.out.println("Chave = " + chave + "\nValor = " + mapaAlunos.get(chave) + "\n");
	}
}
