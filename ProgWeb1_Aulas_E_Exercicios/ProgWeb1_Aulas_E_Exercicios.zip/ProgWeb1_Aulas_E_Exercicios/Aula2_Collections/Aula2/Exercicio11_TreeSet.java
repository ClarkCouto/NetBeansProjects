package Aula2;
import java.util.*;

public class Exercicio11_TreeSet {
	public static void main(String[] args) {
        ComparatorCpf comparador = new ComparatorCpf();
		TreeSet<Cpf> conjunto = new TreeSet<>(comparador);
		conjunto.add(new Cpf(456789, 70));
		conjunto.add(new Cpf(123456, 60));
		for (Cpf cpf : conjunto) {
			System.out.println(cpf.toString());
		}

	}
}
