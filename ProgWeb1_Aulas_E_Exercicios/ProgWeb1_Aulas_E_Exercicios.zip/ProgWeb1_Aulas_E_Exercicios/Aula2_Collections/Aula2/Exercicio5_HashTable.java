package Aula2;
import java.util.*;

public class Exercicio5_HashTable {
	public static void main(String[] args) {
		Hashtable<String, Integer> itens = new Hashtable<>();
	     itens.put("cod1", new Integer(1));
	     itens.put("cod2", 2);
	     itens.put("cod2", new Integer(2));
	     Enumeration<Integer> e = itens.elements();
	     while(e.hasMoreElements()){
	           Integer i = (Integer) e.nextElement();    
	           System.out.println(i);
	     }
	}
}
