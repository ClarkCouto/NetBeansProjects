package Aula2;
import java.util.Set;
import java.util.TreeMap;

public class Exercicio9_TreeMap {
	public static void main(String[] args) {
		//Usando a classe Cpf fa�a
		//Adicionar 4 cpfs em um TreeMap usando os construtores sem e com par�metros
		//A chave � o n�mero do Cpf e o valor � o cpf completo import java.util.*;
		//Ordenar o mapa usando o n�mero e o digito do Cpf
		//Imprimir o mapa ordenado, mostrando chave - valor
		
		TreeMap<Long, Cpf> mapa = new TreeMap<Long, Cpf>();
		mapa.put(15988250L, new Cpf(15988250, 89));
		mapa.put(12345678L, new Cpf(12345678, 91));
		mapa.put(98765432L, new Cpf(98765432, 10));
		mapa.put(12349876L, new Cpf(12349876, 50));
		
		Set<Long> chaves = mapa.keySet();
		for(Long chave: chaves)
			System.out.println("Chave = " + chave + " Valor = " + mapa.get(chave));
	}
}
