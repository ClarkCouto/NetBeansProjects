package Aula2;

public class Pessoa implements Comparable<Pessoa>{
	private String nome;
	private String telefone;
	private String endereco;
	
	public Pessoa(){}
	public Pessoa(String nome, String telefone, String endereco) {
		this.nome = nome;
		this.telefone = telefone;
		this.endereco = endereco;
	}

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	@Override
    public int compareTo(Pessoa p) {
		if(p.nome == null || this.nome == null)
			return -1;
        return this.nome.compareTo(p.getNome()); //Sort in ascending order 
        //return p.getName().compareTo(this.name); Sort in descending order 
        
        //numero, null = -1
        //null , null = 0
        //null, numero = 1
        		
    }
	
	@Override
	public String toString() {
		return "Pessoa [nome=" + nome + "]";
	}
}
