package Aula2;

public class Produto {
	private int codigo;
	private String descricao;
	private double valor;
	
	//fa�a o resto da classe
}
