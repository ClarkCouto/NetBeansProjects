package Aula2;

public class TestePar {
	public static void main(String[] args) {
		Par<Long, String> par1 = new Par<>();
		par1.setPrimeiro(1234L);
		par1.setSegundo("Cris");

		Par<Float, Float> par2 = new Par<>();
		par2.setPrimeiro(34.5F);
		par2.setSegundo(28.3F);
	}
}
