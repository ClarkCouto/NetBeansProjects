package exercicio1_2_ListaGenerica;

public interface Lista<T>{
//	1) CrieainterfacegenéricaListacomodescritoabaixo:
//		• A lista irá conter elementos
//		• A lista está definida no pacote br.edu.ifrs.progweb1.util;
//		• Defina os métodos abaixo usando o conceito de genéricos onde for possível:
//		public void adicionar(Object obj) 
//		public boolean remover(int i) 
//		public String listar()
//		public int totalizar()
//		public void removerTodos()
//		public Object getFirst()
//		public void removeElement(Object obj)
	
	public void adicionar(T t);
	public boolean remover(int posicao);
	public String listar();
	public int totalizar();
	public void removerTodos();
	public T getFirst();
	public void removeElement(T t);
}
