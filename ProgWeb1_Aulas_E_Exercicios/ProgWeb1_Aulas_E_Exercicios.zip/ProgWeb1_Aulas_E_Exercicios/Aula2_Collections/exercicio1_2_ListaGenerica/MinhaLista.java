package exercicio1_2_ListaGenerica;
import java.util.LinkedList;

//Agora, crie a classe MinhaLista que implementa a interface Lista genérica definida previamente. 
//Essa classe deve declarar um atributo da classe LinkedList para armazenar objetos na classe 
//MinhaLista e implemente todos os métodos da interface Lista.

public class MinhaLista<T> implements Lista{
	private LinkedList<T> lista;

	public MinhaLista(){
		lista = new LinkedList<T>();
	}
	
	@Override
	public void adicionar(Object t) {
		lista.add((T)t);
	}

	@Override
	public boolean remover(int posicao) {
		return (boolean) lista.remove(posicao);
	}

	@Override
	public String listar() {
		return lista.toString();
	}

	@Override
	public int totalizar() {
		return lista.size();
	}

	@Override
	public void removerTodos() {
		lista.removeAll(lista);
	}

	@Override
	public T getFirst() {
		return lista.getFirst();
	}

	@Override
	public void removeElement(Object t) {
		lista.remove((T)t);
	}
}
