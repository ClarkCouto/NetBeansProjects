package exercicio4_5_6_Mapa_Interface_Genericos;
import java.util.List;
import java.util.Set;

public interface Mapa<K, V> {
//	4) CrieainterfacegenéricaMapacomodescritoabaixo:
//		• O mapa irá conter elementos compostos por chave e valor
//		• O mapa está definido no pacote br.edu.ifrs.progweb2.util;
//		Defina os métodos abaixo usando o conceito de genéricos onde for possível: public Objec get(Object obj) retorna o valor de uma chave específica
//		public boolean isEmpty() retorna true se o mapa está vazio
//		public Set keySet() retorna um conjunto com todas as chaves
//		public int size() retorna o nnúmero de objetos no mapa
//		public void put(Object chave, Object valor) – adiciona um objeto no mapa usando a chave e o valor
//		public void remove (Object obj) – remove um objeto usando a sua chave
//		public List values() – retorna uma lista com os valores armazenados no mapa
	
		public boolean isEmpty();
		public Set keySet();
		public int size();
		public void put(K c, V v);
		public void remove (V v);
		public List values();
}
