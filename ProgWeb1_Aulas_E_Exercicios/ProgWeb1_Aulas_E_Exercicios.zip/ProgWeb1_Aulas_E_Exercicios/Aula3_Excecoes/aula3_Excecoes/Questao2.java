package aula3_Excecoes;
import java.util.*;
public class Questao2 {
  public static void main(String[] args) {
   	   LinkedList<Telefone>  telefones = new LinkedList<Telefone>();
   	   try{
   	   	   telefones.add(new Telefone());
   	   	   telefones.add(new Telefone(51, 55667788));
   	   	   telefones.add(3, new Telefone(55, 33445566));
   	   }
   	   catch(NullPointerException | IndexOutOfBoundsException e){
   		   System.out.println("Tentou adicionar uma posi��o inv�lida: " + e.getMessage());
   	   }
   	   catch(Exception e){
   		   System.out.println("Ocorreu uma exce��o indeterminada!");
   		   e.getCause();
   		   e.getMessage();
   		   e.printStackTrace();
   	   }
   	   
   	   
   	   try{
   		   telefones.remove(0);
   		   telefones.remove(5);
   		   telefones.remove(1);
   	   }
   	   catch(NullPointerException | IndexOutOfBoundsException e){
   		   System.out.println("Tentou remover uma posi��o inv�lida!");
   	   }
   	   catch(Exception e){
   		   System.out.println("Ocorreu uma exce��o indeterminada!");
   		   e.getCause();
   		   e.printStackTrace();
   	   }
  }
}
