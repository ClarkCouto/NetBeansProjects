package aula3_Excecoes;
public class Questao4 {
	public static void main(String[] args) {
		try {
			int i = (int) Math.random();
			int j = 10 / i;
		} 
		catch (ArithmeticException e) {
    		System.out.println("N�o � poss�vel dividir por 0!");
		}
    	catch(Exception e){
    		System.out.println("Ocorreu uma exce��o indeterminada!");
			e.printStackTrace();
    	}
	}
}
