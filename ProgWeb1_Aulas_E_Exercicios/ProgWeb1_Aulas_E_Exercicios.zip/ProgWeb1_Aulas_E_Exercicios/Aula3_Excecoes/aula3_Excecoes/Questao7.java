package aula3_Excecoes;
import java.util.*;

public class Questao7 {
	public static void main(String args[]) {
		TreeSet<Number> numeros = new TreeSet<>();
		try{
			numeros.add(new Integer(5));
			numeros.add(8);
			numeros.add(new Double(5.9));
			numeros.add(null);
		}
		catch(ClassCastException e){
    		System.out.println("Ocorreu uma erro de convers�o!");
		}
		catch(Exception e){
    		System.out.println("Ocorreu uma exce��o indeterminada!");
			e.printStackTrace();
		}

		for (Number num : numeros)
			System.out.println("Num: " + num);
	}
}
