package Arquivos;
import java.io.*;

public class Arquivo <T> implements Serializable{
	private ObjectOutputStream saida;
	private ObjectInputStream entrada;
	private String nomeArq;

	public Arquivo(String nome) {
		nomeArq = nome;
	}

	public void abrir(String tipo) {
		if (tipo.equals("w")) { // abre para grava��o
			try {
				saida = new ObjectOutputStream(new FileOutputStream(nomeArq));
				System.out.println("Aberto para Grava��o\n");
			} 
			catch (NotSerializableException ex) {
				System.out.println("Arquivo n�o encontrado para escrita!" + ex.getMessage());
			}
			catch (FileNotFoundException | NullPointerException ex) {
				System.out.println("Arquivo nulo ou n�o encontrado para escrita!" + ex.getMessage());
			}
			catch (SecurityException ex) {
				System.out.println("Exce��o de seguran�a na escrita de arquivo!" + ex.getMessage());
			}
			catch (IOException ex) {
				System.out.println("Exce��o IO na escrita de arquivo!" + ex.getMessage());
			}
			catch (Exception ex) {
				System.out.println("Exce��o indefinida na scrita de arquivo!" + ex.getMessage());
			}
		} 
		else { // abre para leitura
			try {
				entrada = new ObjectInputStream(new FileInputStream(nomeArq));
				System.out.println("\nAberto para Leitura\n");
			} 
			catch (NotSerializableException ex) {
				System.out.println("Arquivo n�o pode ser serializado!" + ex.getMessage());
			}
			catch (FileNotFoundException | NullPointerException ex) {
				System.out.println("Arquivo nulo ou n�o encontrado para leitura!" + ex.getMessage());
			}
			catch (SecurityException ex) {
				System.out.println("Exce��o de seguran�a na leitura do arquivo!" + ex.getMessage());
			}
			catch (IOException ex) {
				System.out.println("Exce��o IO na leitura de arquivo!" + ex.getMessage());
			}
			catch (Exception ex) {
				System.out.println("Exce��o indefinida na leitura do arquivo!" + ex.getMessage());
			}
		}
	}

	public void gravarObjeto(T obj) {
		try {
			saida.writeObject(obj);
			saida.flush();
			System.out.println("Dados gravados com sucesso");
		} 
		catch (InvalidClassException ex) {
			System.out.println("Classe inv�lida!" + ex.getMessage());
		}
		catch (StreamCorruptedException ex) {
			System.out.println("Arquivo n�o pode ser serializado!" + ex.getMessage());
		}
		catch (OptionalDataException ex) {
			System.out.println("Arquivo n�o pode ser serializado!" + ex.getMessage());
		}
		catch (FileNotFoundException | NullPointerException ex) {
			System.out.println("Arquivo nulo ou n�o encontrado para escrita!" + ex.getMessage());
		}
		catch (SecurityException ex) {
			System.out.println("Exce��o de seguran�a na escrita do arquivo!" + ex.getMessage());
		}
		catch (IOException ex) {
			System.out.println("Exce��o IO na escrita do arquivo!" + ex.getMessage());
		}
		catch (Exception ex) {
			System.out.println("Exce��o indefinida na grava��o do arquivo!" + ex.getMessage());
		}
	}

	public T lerObjeto() {
		try {
			return (T) entrada.readObject();
		} 
		catch (ClassNotFoundException ex) {
			System.out.println("Classe n�o encontrada!" + ex.getMessage());
		}
		catch (InvalidClassException ex) {
			System.out.println("Classe inv�lida!" + ex.getMessage());
		}
		catch (StreamCorruptedException ex) {
			System.out.println("Stream corrompido!" + ex.getMessage());
		}
		catch (OptionalDataException ex) {
			System.out.println("Exce��o de Dados opcionais!" + ex.getMessage());
		}
		catch (NotSerializableException ex) {
			System.out.println("Arquivo n�o pode ser serializado!" + ex.getMessage());
		}
		catch (FileNotFoundException | NullPointerException ex) {
			System.out.println("Arquivo nulo ou n�o encontrado para leitura!" + ex.getMessage());
		}
		catch (IOException ex) {
			System.out.println("Exce��o IO na leitura do arquivo!" + ex.getMessage());
		}
		catch (Exception ex) {
			System.out.println("Exce��o indefinida na leitura do arquivo!" + ex.getMessage());
		}
		return null;
	}

	public void fechar() {
		if(saida != null){
			try {
				saida.close();
				System.out.println("Sa�da fechada com sucesso");
			} 
			catch (IOException ex) {
				System.out.println("Exce��o no fechamento da Escrita do arquivo!" + ex.getMessage());
			}
			catch (Exception ex) {
				System.out.println("Exce��o indefinida no fechamento da Escrita do arquivo!" + ex.getMessage());
			}
		}
		if(entrada != null){
			try {
				entrada.close();
				System.out.println("Entrada fechada com sucesso");
			}
			catch (IOException ex) {
				System.out.println("Exce��o no fechamento da Leitura do arquivo!" + ex.getMessage());
			}
			catch (Exception ex) {
				System.out.println("Exce��o indefinida no fechamento da Leitura do arquivo!" + ex.getMessage());
			}
		}
	}
}
