package Arquivos;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Questao1 {
//	public static void main(String[] args) {
//		Scanner entrada = new Scanner(System.in);
//		System.out.printf("Informe o n�mero para a tabuada:\n");
//		int n = entrada.nextInt();
//		System.out.printf("Informe a pasta:\n");
//		String pasta = entrada.nextLine();
//		FileWriter arq = new FileWriter(pasta+"\\tabuada.txt");
//		PrintWriter gravarArq = new PrintWriter(arq);
//		gravarArq.printf("+--Resultado--+%n");
//		for (int i = 1; i <= 10; i++) {
//			gravarArq.printf("| %2d X %d = %2d |%n", i, n, (i * n));
//		}
//		gravarArq.printf("+-------------+%n");
//		arq.close();
//		System.out.println("\nTabuada do " + n + " foi gravada na " + 
//                                                pasta + "\tabuada.txt\n");
//	}
	

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		System.out.printf("Informe o n�mero para a tabuada:\n");
		int n = entrada.nextInt();

		entrada.nextLine();
		System.out.printf("Informe a pasta:\n");
		String pasta = entrada.nextLine();
		
		try (FileWriter arq = new FileWriter(pasta+"\\tabuada.txt");){
			PrintWriter gravarArq = new PrintWriter(arq);
			gravarArq.printf("+--Resultado--+%n");
			for (int i = 1; i <= 10; i++) {
				gravarArq.printf("| %2d X %d = %2d |%n", i, n, (i * n));
			}
			gravarArq.printf("+-------------+%n");
			System.out.println("\nTabuada do " + n + " foi gravada na " + 
	                                                pasta + "\\tabuada.txt\n");
		} 
		catch (FileNotFoundException ex) {
			System.out.println("Arquivo n�o encontrado!" + ex.getMessage());
		}
		catch (IOException ex) {
			System.out.println("Exce��o de Leitura/Escrita de arquivo!" + ex.getMessage());
		}
		entrada.close();
		
	}
}

