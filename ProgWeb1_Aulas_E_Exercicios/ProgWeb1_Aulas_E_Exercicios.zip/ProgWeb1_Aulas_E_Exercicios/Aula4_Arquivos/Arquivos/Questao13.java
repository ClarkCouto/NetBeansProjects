package Arquivos;
import java.io.FileOutputStream;
import java.util.LinkedList;

public class Questao13 {

	public static void main(String[] args) {
		System.out.println("==========================================\n"
						+  "=========== Usando arquivo comum =========\n"
						+  "==========================================\n");
		Arquivo<Pessoa> pessoas = new Arquivo<Pessoa>("Questao13.txt");
		
		pessoas.abrir("w");
		pessoas.gravarObjeto(new Pessoa("Cris", 27));
		pessoas.gravarObjeto(new Pessoa("Matheus", 22));
		pessoas.gravarObjeto(new Pessoa("Thayse", 24));
		
		pessoas.abrir("r");
		Pessoa obj = (Pessoa) pessoas.lerObjeto();
		System.out.println("Pessoa 1: " + obj.toString());
		obj = (Pessoa) pessoas.lerObjeto();
		System.out.println("Pessoa 2: " + obj.toString());
		obj = (Pessoa) pessoas.lerObjeto();
		System.out.println("Pessoa 3: " + obj.toString());
		
		System.out.println("");
		pessoas.fechar();

		System.out.println("\n\n==========================================\n"
						+  "======== Usando lista de arquivos ========\n"
						+  "==========================================\n");
		
		LinkedList<Pessoa> lista = new LinkedList<>();
		lista.add(new Pessoa("Cris", 27));
		lista.add(new Pessoa("Matheus", 22));
		lista.add(new Pessoa("Thayse", 24));
		
		Arquivo<LinkedList<Pessoa>> arquivo = new Arquivo<>("Questao13_UsandoLinkedList.txt");
		arquivo.abrir("w");
		arquivo.gravarObjeto(lista);
		arquivo.fechar();

		arquivo.abrir("r");
		LinkedList<Pessoa> listaPessoas = (LinkedList<Pessoa>) arquivo.lerObjeto();
		for(Pessoa p : listaPessoas)
			System.out.println(p.toString());

		System.out.println("");
		arquivo.fechar();

	}

}
