package Arquivos;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Questao3 {
	public static void main(String[] args) {
		File arquivo = new File("Questao3.txt");
		
		if(!arquivo.exists()){
			try {
				arquivo.createNewFile();
			}
			catch (SecurityException ex) {
				System.out.println("Exce��o de seguran�a! " + ex.getMessage());
			}
			catch (IOException ex) {
				System.out.println("Exce��o de Leitura/Escrita de arquivo!" + ex.getMessage());
			}
		}
		try(FileReader fr = new FileReader(arquivo);){
			char[]  c =  new char[4];
			fr.read(c);
			System.out.print( c );
		} 
		catch (FileNotFoundException ex) {
			System.out.println("Arquivo n�o encontrado!" + ex.getMessage());
		}
		catch (IOException ex) {
			System.out.println("Exce��o de Leitura/Escrita de arquivo!" + ex.getMessage());
		}
	}
}
