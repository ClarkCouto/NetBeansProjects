package Arquivos;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Questao6{
	public static void main(String[] args) {
		File arquivo = new File("Ex6.txt");
		
		//Escrever arquivo
		try (FileWriter fw = new FileWriter( arquivo );){
			BufferedWriter escrita = new BufferedWriter(fw);             
			escrita.write("teste1");
			escrita.newLine();
			escrita.write("teste2");
		} 
		catch (FileNotFoundException ex) {
			System.out.println("Arquivo n�o encontrado!" + ex.getMessage());
		}
		catch (IOException ex) {
			System.out.println("Exce��o de Leitura/Escrita de arquivo!" + ex.getMessage());
		}
		
		//Ler arquivo
		try (FileReader fr = new FileReader(arquivo);){
			BufferedReader leitura = new BufferedReader(fr);
			String content;
			while((content = leitura.readLine()) != null){
			    System.out.println(content);
			}
		} 
		catch (FileNotFoundException ex) {
			System.out.println("Arquivo n�o encontrado!" + ex.getMessage());
		}
		catch (IOException ex) {
			System.out.println("Exce��o de Leitura/Escrita de arquivo!" + ex.getMessage());
		}
	}
}
