package trabalho1;
//15) Defina a classe MinhaLista observando as seguintes regras:
//- MinhaLista deve ser definida como gen�rica e usar a interface Lista (Quest�o 14)
//- Use a classe LinkedList para armazenar objetos na classe MinhaLista
//- Use todos os conceitos de gen�ricos e observe os conceitos de tratamento de exce��es
//- Defina os m�todos adicionar, remover e getUltimo considerando as observa��es abaixo:
//1. public void adicionar(int indice, Object obj)- m�todo deve tratar a exce��o definida
//pela documenta��o
//2. public Object remover(Object obj) � m�todo deve propagar a exce��o definida pela
//documenta��o
//3. public int getUltimo() � m�todo deve causar a exce��o definida pela documenta��o
//4. public String toString() 

import java.util.LinkedList;
import java.util.NoSuchElementException;

public class MinhaLista<E> implements Lista<E>{
	private LinkedList<E> lista;
	
	public MinhaLista(){
		lista = new LinkedList<E>();
	}
	
	public MinhaLista(LinkedList<E> lista) {
		this.lista = lista;
	}

	@Override
	public void adicionar(int indice, E elemento) {
		try{
			lista.add(indice, elemento);
		}
		catch(ArrayIndexOutOfBoundsException ex) {
			System.out.println("ArrayIndexOutOfBoundsException :" + ex.getMessage());
		}  
		catch(Exception ex) {
			System.out.println("Ocorreu uma exce��o:" + ex.getMessage());
		} 
	}

	@Override
	public boolean remover(E elemento) throws NoSuchElementException{
		return lista.remove(elemento);
	}
	
	//M�todo criado para poder retirar um elemento da lista
	public E getElemento(int indice){
		return lista.get(indice);
	}

	@Override
	public String listar() {
		if(totalizar() == 0)
			return "Lista vazia!";
		
		String retorno = "";
		for(int i = 0; i < lista.size(); i++){
			retorno += (i + 1) + " - " + lista.get(i).toString() + "\n";
		}
		return retorno;
	}

	@Override
	public int totalizar() {
		return lista.size();
	}

	@Override
	public E getFirst() {
		return lista.getFirst();
	}

	@Override
	public E getLast(){
		throw new NoSuchElementException();
	}
}
