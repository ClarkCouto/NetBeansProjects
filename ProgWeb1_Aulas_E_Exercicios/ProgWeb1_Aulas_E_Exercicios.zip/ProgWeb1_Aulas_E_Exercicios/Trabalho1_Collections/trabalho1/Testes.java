package trabalho1;
import java.util.NoSuchElementException;

import javax.swing.JOptionPane;

//16) Crie uma classe de Testes para testar a lista definida na quest�o 15. 
//Essa classe deve fazer os tratamentos das exce��es, quando for necess�rio.

public class Testes {

	public static void main(String[] args) {
		MinhaLista<String> lista = new MinhaLista<String>();
		/*
		//Teste autom�tico
		//Adiciona Elementos na lista
		for(int i = 0; i < 10; i++){
			lista.adicionar(i, " N�mero " + (i + 1));
		}

		System.out.println("Imprime lista completa!");
		System.out.println("Tamanho da lista: " + lista.totalizar());
		//Imprime a lista completa
		System.out.println(lista.listar());

		System.out.print("Imprime primeiro elemento:");
		//Imprime o primeiro elemento
		System.out.println(lista.getFirst());

		System.out.print("\nImprime �ltimo elemento:");
		//Imprime �ltimo elemento		
		try{
			System.out.println(lista.getLast());
		}
		catch(NoSuchElementException ex){
			System.out.println(" Fun��o n�o implementada!");
		}
		catch(Exception ex){
			System.out.println(" Exce��o n�o tratada encontrada!");
		}

		System.out.print("\nImprime o primeiro elemento!");
		//Imprime o primeiro elemento 
		System.out.println(lista.getFirst());

		System.out.print("\nTenta retirar o elemento 'N�mero 5': ");
		//Retira o elemento "N�mero 5" 
		String retirou = lista.remover("5 N�mero") ? "Elemento retirado" : "Elemento n�o foi encontrado";
		System.out.println(retirou);
		
		System.out.print("\nRetira o primeiro elemento da lista: ");
		//Retira o primeiro elemento 
		retirou = lista.remover(lista.getFirst()) ? "Elemento retirado" : "Elemento n�o foi encontrado";
		System.out.println(retirou);
		
		System.out.println("\nImprime lista completa novamente!");
		System.out.println("Tamanho da lista: " + lista.totalizar());
		//Imprime a lista Final
		System.out.println(lista.listar());
		*/
		//Teste manual
		int opcao = 777;
		lista = new MinhaLista<String>();
		
		while(opcao != 0){
			opcao = menu();
			try{
				switch(opcao){
					case 0:
						System.exit(0);
					case 1:
						lista.adicionar(lista.totalizar(), JOptionPane.showInputDialog("Digite o elemento a ser inserido: "));
						break;
					case 2:
						int indice = Integer.parseInt(JOptionPane.showInputDialog("Digite o �ndice do elemento a ser retirado: "));
						lista.remover(lista.getElemento(indice));
						break;
					case 3:
						JOptionPane.showMessageDialog(null, lista.listar());
						break;
					case 4:
						JOptionPane.showMessageDialog(null, "A lista cont�m " + lista.totalizar() + (lista.totalizar() == 1 ? " elemento" : " elementos"));
						break;
					case 5:
						JOptionPane.showMessageDialog(null, "O primeiro elemento da lista �:  " + lista.getFirst().toString());
						break;
					case 6:
						JOptionPane.showMessageDialog(null, "O �ltimo elemento da lista �:  " + lista.getLast().toString());
						break;
					default:
						JOptionPane.showMessageDialog(null, "Op��o inv�lida!");
						break;
				}
			}
			catch(NumberFormatException  ex) {
				JOptionPane.showMessageDialog(null, "Erro de convers�o: " + ex.getMessage());
			} 
			catch(IndexOutOfBoundsException ex) {
				JOptionPane.showMessageDialog(null, "Posi��o inv�lida: " + ex.getMessage());
			}  
			catch(NoSuchElementException ex){
				JOptionPane.showMessageDialog(null, "M�todo n�o implementado: ");
			}
			catch(Exception ex) {
				JOptionPane.showMessageDialog(null,"Ocorreu uma exce��o :" + ex.getMessage());
			} 
		}
	}

	public static int menu(){
		try{
			return Integer.parseInt(JOptionPane.showInputDialog(
					"============== Menu =============\n" + 
					"1 - Adicionar Elemento\n" + 
					"2 - Remover Elemento\n" + 
					"3 - Listar Elementos\n" + 
					"4 - Totalizar Lista\n" + 
					"5 - Retornar Primeiro Elemento\n" +
					"6 - Retornar �ltimo Elemento\n" +
					"0 - Encerrar\n" + 
					"Digite a op��o desejada:"));
		}
		catch(Exception e){
			return 777;
		}
	}
	

}
