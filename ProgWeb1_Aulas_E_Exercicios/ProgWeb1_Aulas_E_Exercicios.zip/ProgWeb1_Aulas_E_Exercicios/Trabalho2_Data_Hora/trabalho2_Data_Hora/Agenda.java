package trabalho2_Data_Hora;

import java.util.LinkedList;

public class Agenda {
	private LinkedList<Consulta> consultas;

	public Agenda() {
		this.consultas = new LinkedList<>();
	}
	
	public Agenda(LinkedList<Consulta> consultas) {
		this.consultas = consultas;
	}

	public LinkedList<Consulta> getConsultas() {
		return consultas;
	}

	public void setConsultas(LinkedList<Consulta> consultas) {
		this.consultas = consultas;
	}
	
	public Consulta buscarConsulta(int index){
		return consultas.get(index);
	}
	
	public void adicionarConsulta(Consulta consulta){
		consultas.add(consulta);
	}
	
	public void removerTodasConsultas(){
		consultas.removeAll(consultas);
	}
	
	public void removerConsulta(Consulta consulta){
		consultas.remove(consulta);
	}
	
	public int getQuantidadeDeConsultas(){
		return consultas.size();
	}
	
	public String getConsultasDetalhadas(){
		String str = "";
		for (Consulta consulta : consultas)
			str += consulta.toString();
		return "================ Consultas Marcadas =============== \n" + str;
	}
	@Override
	public String toString() {
		return consultas.size() != 0 ? getConsultasDetalhadas() : "A agenda de consultas est� vazia!";
	}
}
