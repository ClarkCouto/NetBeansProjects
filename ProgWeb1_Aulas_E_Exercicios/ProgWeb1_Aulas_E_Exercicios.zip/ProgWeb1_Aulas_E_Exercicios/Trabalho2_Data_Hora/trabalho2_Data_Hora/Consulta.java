package trabalho2_Data_Hora;
import java.text.NumberFormat;
import java.util.Locale;

public class Consulta {
	//22.3 Classe Consulta - a classe consulta possui uma data, um horaÌ�rio e um paciente
	private Paciente paciente;
	private Data data;
	private Horario horario;
	private double valor;
	
	public Consulta(){}
	
	public Consulta(Paciente paciente, Data data, Horario horario, double valor) {
		this.paciente = paciente;
		this.data = data;
		this.horario = horario;
		this.valor = valor;
	}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}

	public Data getData() {
		return data;
	}

	public void setData(Data data) {
		this.data = data;
	}

	public Horario getHorario() {
		return horario;
	}

	public void setHorario(Horario horario) {
		this.horario = horario;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	@Override
	public String toString() {
		//22.3 Classe Consulta - o meÌ�todo toString() deve formatar o valor usando a moeda corrente do paiÌ�s,
		//e o nuÌ�mero deve ter no maÌ�ximo 3 casas para a parte inteira e 4 casas para a parte fracionaÌ�ria
		NumberFormat formatter = NumberFormat.getCurrencyInstance(new Locale ("pt", "BR"));
		formatter.setMaximumIntegerDigits(3);
		formatter.setMaximumFractionDigits(4);
		
		return "=================== Consulta ===================\n" 
				+ paciente + "\nData = " + data + "\n" + horario 
				+ "\nValor: " + formatter.format(valor) + "\n";
	}
}