package trabalho2_Data_Hora;

import java.util.NoSuchElementException;

import javax.swing.JOptionPane;

public class TesteConsulta {

	public static void main(String[] args) {
		Agenda agenda = new Agenda();

		System.out.println("Criando Consultas...\n...");
		//Criando e inserindo consultas manualmente
		//23.1 objeto consulta1 - usa o construtor sem parâmetros e inicializa todos os atributos usando get/set
		Consulta consulta1 = new Consulta();
		consulta1.setPaciente(new Paciente("Paciente 1", 27, "Rua X", "99999999"));
		consulta1.setData(new Data(04, 05, 2017));
		consulta1.setHorario(new Horario(11, 00, 00));
		consulta1.setValor(100.12345);
		agenda.adicionarConsulta(consulta1);

		System.out.println("Consulta 1 - Criada com construtor sem par�metros e inicalizando atributos via m�todos...\n...");
		//23.2 objeto consulta2 - usa o construtor com parâmetros
		Consulta consulta2 = new Consulta(new Paciente("Paciente 2", 22, "Rua Y", "88888888"), 
										  new Data(03, 07, 2017),
										  new Horario(13, 40, 00),
										  200.67896);
		agenda.adicionarConsulta(consulta2);
		System.out.println("Consulta 2 - Criada com construtor com par�metros...\n...");
		
		System.out.println("Lista de consultas criadas:");
		System.out.println(agenda.toString());
		
		System.out.println("Demais opera��es devem ser feitas pelo menu...");

		
		int opcao = 777;
		
		while(opcao != 0){
			try{
				opcao = menu();
				switch(opcao){
					case 0:
						System.exit(0);
					case 1:
						criarConsulta(agenda);
						break;
					case 2:
						removerConsulta(agenda);
						break;
					case 3:
						removerTodasConsultas(agenda);
						break;
					case 4:
						listarConsultas(agenda);
						break;
					case 5:
						JOptionPane.showMessageDialog(null, agenda.getQuantidadeDeConsultas() == 0 ? "A lista est� vazia!" : "A lista cont�m " + agenda.getQuantidadeDeConsultas() + (agenda.getQuantidadeDeConsultas() == 1 ? " consulta" : " consultas"));
						break;
					default:
						JOptionPane.showMessageDialog(null, "Op��o inv�lida!");
						break;
				}
			}
			catch(NumberFormatException  ex) {
				JOptionPane.showMessageDialog(null, "Op��o inv�lida. As op��es v�o de 0 � 4.");
			} 
			catch(NoSuchElementException ex){
				JOptionPane.showMessageDialog(null, "Elemento n�o encontrado. " + ex.getMessage());
			}
			catch(Exception ex) {
				JOptionPane.showMessageDialog(null,"Ocorreu uma exce��o. 1 " + ex.getMessage());
			} 
		}
	}

	public static int menu(){
		return Integer.parseInt(JOptionPane.showInputDialog(
				"============== Menu =============\n" + 
				"1 - Adicionar Consulta\n" + 
				"2 - Remover Consulta\n" + 
				"3 - Remover Todas as Consultas\n" + 
				"4 - Listar Consultas\n" + 
				"5 - Total de Consultas Agendadas\n" + 
				"0 - Encerrar\n" + 
				"Digite a op��o desejada:"));
	}
	
	public static void criarConsulta(Agenda agenda){
		try{
			agenda.adicionarConsulta(new Consulta(criarPaciente(), criarData(), criarHorario(), criarValor()));
			JOptionPane.showMessageDialog(null, "Consulta criada com sucesso!");
		}
		catch (NullPointerException ex) {
			JOptionPane.showMessageDialog(null, "Opera��o foi cancelada");
		}
		catch (UnsupportedOperationException ex) {
			JOptionPane.showMessageDialog(null, "Opera��o n�o permitida. " + ex.getMessage());
		}
		catch(NoSuchElementException ex){
			JOptionPane.showMessageDialog(null, "Elemento n�o encontrado. " + ex.getMessage());
		}
		catch(Exception ex) {
			JOptionPane.showMessageDialog(null,"Ocorreu uma exce��o. " + ex.getMessage());
		} 
	}
	
	public static boolean removerConsulta(Agenda agenda){
		String nome = buscarNome().toUpperCase();
		Data data = criarData();
		int index;
		for (index = 0; index < agenda.getQuantidadeDeConsultas(); index++) {
			Consulta consulta = agenda.buscarConsulta(index);
			if(consulta.getPaciente().getNome().toUpperCase().equals(nome)){
				if(consulta.getData().toString().equals(data.toString())){
					try{
						agenda.removerConsulta(consulta);
						JOptionPane.showMessageDialog(null, "A consulta do paciente " + nome + " no dia " + 
								data + " foi desmarcada com sucesso!");
						return true;
					}
					catch(NoSuchElementException ex){
						JOptionPane.showMessageDialog(null, "Elemento n�o encontrado. " + ex.getMessage());
					}
					catch(Exception ex) {
						JOptionPane.showMessageDialog(null,"Ocorreu uma exce��o. 3 " + ex.getMessage());
					} 
				}
			}
		}
		JOptionPane.showMessageDialog(null, "N�o foi encontrada nenhuma consulta do paciente " 
											+ nome + " no dia " + data + "!");
		return false;
	}

	public static boolean removerTodasConsultas(Agenda agenda){
		if(agenda.getQuantidadeDeConsultas() != 0){
			try{
				agenda.removerTodasConsultas();
				JOptionPane.showMessageDialog(null, "A lista foi esvaziada com sucesso!");
				return true;
			}
			catch(NullPointerException ex){
				JOptionPane.showMessageDialog(null, "Elemento nulo. " + ex.getMessage());
			}
			catch(NoSuchElementException ex){
				JOptionPane.showMessageDialog(null, "Elemento n�o encontrado. " + ex.getMessage());
			}
			catch(Exception ex) {
				JOptionPane.showMessageDialog(null,"Ocorreu uma exce��o. 3 " + ex.getMessage());
			} 
		}
		else{
			JOptionPane.showMessageDialog(null, "A agenda j� est� vazia!");
		}
		return false;
	}
	
	public static void listarConsultas(Agenda agenda){
		JOptionPane.showMessageDialog(null, agenda.toString());
	}

	public static String buscarNome(){
		return JOptionPane.showInputDialog(null, "Nome do paciente: ","Paciente - Nome", JOptionPane.QUESTION_MESSAGE).toUpperCase();
	}
	
	public static Paciente criarPaciente(){
		Paciente paciente = null;
		String nome = buscarNome();
		if(nome != null){
			int idade = 0;
			boolean idadeValida = false;
			while(!idadeValida){
				try{
					idade = Integer.parseInt(JOptionPane.showInputDialog(null, "Idade do paciente: ","Paciente - Idade", JOptionPane.QUESTION_MESSAGE));
					idadeValida = true;
				}
				catch(NumberFormatException ex){
					JOptionPane.showMessageDialog(null, "Erro de convers�o. " + ex.getMessage());
				} 
				catch(IndexOutOfBoundsException ex) {
					JOptionPane.showMessageDialog(null, "Posi��o inv�lida. " + ex.getMessage());
				}  
				catch(Exception ex) {
					JOptionPane.showMessageDialog(null,"Ocorreu uma exce��o. 4 " + ex.getMessage());
				} 
			}
			String endereco = JOptionPane.showInputDialog(null, "Endere�o do paciente: ","Paciente - Endere�o", JOptionPane.QUESTION_MESSAGE);
			String telefone = JOptionPane.showInputDialog(null, "Telefone do paciente: ","Paciente - Telefone", JOptionPane.QUESTION_MESSAGE);
			
			try{
				paciente = new Paciente(nome, idade, endereco, telefone);
			}
			catch (NullPointerException ex) {
				JOptionPane.showMessageDialog(null, "Opera��o foi cancelada. " + ex.getMessage());
			}
			catch (UnsupportedOperationException ex) {
				JOptionPane.showMessageDialog(null, "Opera��o n�o permitida. " + ex.getMessage());
			}
			catch(NoSuchElementException ex){
				JOptionPane.showMessageDialog(null, "Elemento n�o encontrado. " + ex.getMessage());
			}
			catch(Exception ex) {
				JOptionPane.showMessageDialog(null,"Ocorreu uma exce��o. 5 " + ex.getMessage());
			} 
		}
		return paciente;
	}
	
	public static Data criarData(){
		Data data = null;
		boolean dataValida = false;
		while(!dataValida){
			String[] dados = JOptionPane.showInputDialog(null, "Data da Consulta (dd/mm/yyyy): ", "Data", JOptionPane.QUESTION_MESSAGE).split("/");
			if(dados.length == 3){
				try{
					data = new Data(Integer.parseInt(dados[0]), Integer.parseInt(dados[1]), Integer.parseInt(dados[2]));
					dataValida = true;
				}
				catch (NullPointerException ex) {
					JOptionPane.showMessageDialog(null, "Opera��o foi cancelada. " + ex.getMessage());
				}
				catch(NumberFormatException ex){
					JOptionPane.showMessageDialog(null, "Erro de convers�o. " + ex.getMessage());
				} 
				catch(IndexOutOfBoundsException ex) {
					JOptionPane.showMessageDialog(null, "Posi��o inv�lida. " + ex.getMessage());
				}  
				catch(Exception ex) {
					JOptionPane.showMessageDialog(null,"Ocorreu uma exce��o. 6 " + ex.getMessage());
				} 
			}
			else{
				JOptionPane.showMessageDialog(null,"Formato de data inv�lido. Formato correto = dd/mm/yyyy");
			}
		}
		return data;
	}
	
	public static Horario criarHorario(){
		Horario horario = null;
		boolean horaValida = false;
		while(!horaValida){
			String[] dados = JOptionPane.showInputDialog(null, "Hor�rio da Consulta (hh:mm:ss): ","Hor�rio",JOptionPane.QUESTION_MESSAGE).split(":");
			if(dados.length == 3){
				try{
					horario = new Horario(Integer.parseInt(dados[0]), Integer.parseInt(dados[1]), Integer.parseInt(dados[2]));
					horaValida = true;
				}
				catch (NullPointerException ex) {
					JOptionPane.showMessageDialog(null, "Opera��o foi cancelada. " + ex.getMessage());
				}
				catch(NumberFormatException ex){
					JOptionPane.showMessageDialog(null, "Erro de convers�o. " + ex.getMessage());
				} 
				catch(IndexOutOfBoundsException ex) {
					JOptionPane.showMessageDialog(null, "Posi��o inv�lida. " + ex.getMessage());
				}  
				catch(Exception ex) {
					JOptionPane.showMessageDialog(null,"Ocorreu uma exce��o. 7 " + ex.getMessage());
				} 
			}
			else{
				JOptionPane.showMessageDialog(null,"Formato de hor�rio inv�lido. Formato correto = hh:mm:ss");
			}
		}
		return horario;
	}
	
	public static Double criarValor(){
		Double valor = null;
		boolean valorValido = false;
		while(!valorValido){
			try{
				valor = Double.parseDouble(JOptionPane.showInputDialog(null, "Valor da Consulta R$: ","Valor",JOptionPane.QUESTION_MESSAGE));
				if(valor < 0 || valor > 999.99){
					JOptionPane.showMessageDialog(null, "O valor da consulta deve ser positivo e menor que R$ 1000");
				}
				else{
					valorValido = true;
				}
			}
			catch (NullPointerException ex) {
				JOptionPane.showMessageDialog(null, "Opera��o foi cancelada");
			}
			catch(NumberFormatException ex){
				JOptionPane.showMessageDialog(null, "Erro de convers�o. " + ex.getMessage());
			} 
			catch(IndexOutOfBoundsException ex) {
				JOptionPane.showMessageDialog(null, "Posi��o inv�lida. " + ex.getMessage());
			}  
			catch(Exception ex) {
				JOptionPane.showMessageDialog(null,"Ocorreu uma exce��o. 8 " + ex.getMessage());
			} 
		}
		return valor;
	}
}